const initialState = {
    users : [],
    loggedInUser : null,
    products : [{
        
    }
    ]
}