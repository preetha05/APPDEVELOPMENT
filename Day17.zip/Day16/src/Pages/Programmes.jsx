import React from 'react'

const Programmes = () => {
  return (
    <div className='program-container'>
      <h1>PROGRAMMES</h1>
    </div>
  )
}

export default Programmes
