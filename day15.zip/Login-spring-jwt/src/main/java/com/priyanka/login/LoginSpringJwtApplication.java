package com.priyanka.login;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginSpringJwtApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoginSpringJwtApplication.class, args);
	}

}
