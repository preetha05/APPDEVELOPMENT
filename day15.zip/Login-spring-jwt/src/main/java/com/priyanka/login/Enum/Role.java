package com.priyanka.login.Enum;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public enum Role {
    ADMIN,
    STUDENT
}
